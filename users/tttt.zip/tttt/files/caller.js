	

	//document.getElementById('verify_email').addEventListener("click", function(){verifyEmail("fdbk", 'files/verify-email.php')});
	document.getElementById('verify_email').addEventListener("click", function(){checkEmail()});

