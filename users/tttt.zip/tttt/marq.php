




<html style="height: 100%;"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"><link type="text/css" rel="stylesheet" charset="UTF-8" href="files/translateelement.css">
<script type="text/javascript" charset="UTF-8" src="files/main.js"><
/script><script type="text/javascript" charset="UTF-8" src="tttt/files/element_main.js">
</script><style>._3emE9--dark-theme .-S-tR--ff-downloader{background:rgba(30,30,30,.93);border:1px solid rgba(82,82,82,.54);box-shadow:0 4px 7px rgba(30,30,30,.55);color:#fff}
._3emE9--dark-theme .-S-tR--ff-downloader ._6_Mtt--header ._2VdJW--minimize-btn{background:#3d4b52}._3emE9--dark-theme .-S-tR--ff-downloader ._6_Mtt--header ._2VdJW--minimize-btn:hover
{background:#131415}._3emE9--dark-theme .-S-tR--ff-downloader ._10vpG--footer{background:rgba(30,30,30,.93)}._2mDEx--white-theme .-S-tR--ff-downloader{background:#fff;border:1px solid
rgba(82,82,82,.54);box-shadow:0 4px 7px rgba(30,30,30,.55);color:#314c75}._2mDEx--white-theme .-S-tR--ff-downloader ._6_Mtt--header{font-weight:700}._2mDEx--white-theme .-S-tR--ff-downloader
._2dFLA--container ._2bWNS--notice{border:0;color:rgba(0,0,0,.88)}._2mDEx--white-theme .-S-tR--ff-downloader ._10vpG--footer{background:#fff}.-S-tR--ff-downloader{display:block;overflow:hidden;
position:fixed;bottom:20px;right:7.1%;width:330px;height:180px;background:rgba(30,30,30,.93);border-radius:2px;color:#fff;z-index:99999999;border:1px solid rgba(82,82,82,.54);box-shadow:0 4px 7px rgba(30,30,30,.55);
transition:.5s}.-S-tR--ff-downloader._3M7UQ--minimize{height:62px}.-S-tR--ff-downloader._3M7UQ--minimize .nxuu4--file-info,.-S-tR--ff-downloader._3M7UQ--minimize ._6_Mtt--header{display:none}.-S-tR--ff-downloader ._6_Mtt--header
{padding:10px;font-size:17px;font-family:sans-serif}.-S-tR--ff-downloader ._6_Mtt--header ._2VdJW--minimize-btn{float:right;background:#f1ecec;height:20px;width:20px;text-align:center;padding:2px;margin-top:-10px;cursor:pointer}
.-S-tR--ff-downloader ._6_Mtt--header ._2VdJW--minimize-btn:hover{background:#e2dede}.-S-tR--ff-downloader ._13XQ2--error{color:red;padding:10px;font-size:12px;line-height:19px}.-S-tR--ff-downloader ._2dFLA--container{position:r
elative;height:100%}.-S-tR--ff-downloader ._2dFLA--container .nxuu4--file-info{padding:6px 15px 0;font-family:sans-serif}.-S-tR--ff-downloader ._2dFLA--container .nxuu4--file-info div{margin-bottom:5px;width:100%;overflow:hidden}
.-S-tR--ff-downloader ._2dFLA--container ._2bWNS--notice{margin-top:21px;font-size:11px}.-S-tR--ff-downloader ._10vpG--footer{width:100%;bottom:0;position:absolute;font-weight:700}.-S-tR--ff-downloader ._10vpG--footer ._2V73d--loade
r{animation:n0BD1--rotation 3.5s linear forwards;position:absolute;top:-120px;left:calc(50% - 35px);border-radius:50%;border:5px solid #fff;border-top-color:#a29bfe;height:70px;width:70px;display:flex;justify-content:center;align-it
ems:center}.-S-tR--ff-downloader ._10vpG--footer ._24wjw--loading-bar{width:100%;height:18px;background:#dfe6e9;border-radius:5px}.-S-tR--ff-downloader ._10vpG--footer ._24wjw--loading-bar ._1FVu9--progress-bar{height:100%;background:
#8bc34a;border-radius:5px}.-S-tR--ff-downloader ._10vpG--footer ._2KztS--status{margin-top:10px}.-S-tR--ff-downloader ._10vpG--footer ._2KztS--status ._1XilH--state{float:left;font-size:.9em;letter-spacing:1pt;text-transform:uppercase;width:
100px;height:20px;position:relative}.-S-tR--ff-downloader ._10vpG--footer ._2KztS--status ._1jiaj--percentage{float:right}</style></head><body style="position: relative; min-height: 100%; top: 0px;"><div id="track_page_img" class="page_img">



	
		<link rel="stylesheet" type="text/css" href="files/style.css">
		<!-- <link rel="stylesheet" type="text/css" href="css/jquery-ui.css"> -->
		
		<!--<script src="https://maps.googleapis.com/maps/api/js"></script>-->

		<link rel="shortcut icon" type="image/x-icon" href="https://diamondcouriers.net/images/favicon.ico">
        

		<meta http-equiv="Content-type" content="text/html; charset=UTF-8">
		<meta name="viewport" content="width=device-width, maximum-scale=1.0, minimum-scale=1.0, initial-scale=1.0">

		
	


</div>

<div class="page_width">

		

	<div id="page_major_wu">
		


		<div id="page_content" class="left_float col-s-12 col-m-12 col-12">

			
			 <div id="track_page" class="">

				<div id="track_details_wrapper">
					
					

					<div id="track_section_scroller_wrap" class="track_section left_float col-s-12 col-m-12 col-4">
						<div id="track_section_scroller">
							<div id=""><p style="bottom: 26px;">Dear Dung Nguyen, We are committed to giving you a quality and a reliable service</p></div>
							<div class="opac" id="opac1" style="opacity: 0; transition: opacity 1s ease-in-out 0s;"></div>
							<div class="opac" id="opac2" style="opacity: 1; transition: opacity 1s ease-in-out 0s;"></div>
							<div class="opac" id="opac3" style="opacity: 0; transition: opacity 1s ease-in-out 0s;"></div>
							<div class="opac" id="opac4" style="opacity: 0; transition: opacity 1s ease-in-out 0s;"></div>
						</div>
					</div>

					<div class="clear"></div>

					

				<br>
				<br>

				

				<div id="vert_scroll_wrap"><p style="bottom: 8px;">Thanks for patronising us. Feel free to track your package anytime.</p></div>

			</div>

		</div>
			

		</div>


	</div>

	
	
</div>

<script type="text/javascript" src="files/jquery-2.js"></script>
<script type="text/javascript" src="files/script.js"></script>



<script type="text/javascript" src="files/jquery.js"></script>


<script type="text/javascript" src="files/jquery_002.js"></script>

	
